package org.pinae.ndb.action;

/**
 * 基础行为
 * 
 * @author Huiyugeng
 *
 *
 */
public interface Action {

}
