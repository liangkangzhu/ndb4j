package test.org.pinae.ndb.common;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.Map;

import org.junit.Test;
import org.pinae.ndb.common.Converter;
import org.pinae.ndb.common.Loader;

public class ConverterTest {
	@Test
	public void testConvertToJSON(){
		Loader loader = new Loader();
		
		Converter converter = new Converter();
		
		try {
			Map<String, Object> configMap = loader.load("example_1.txt");
			
			String result = converter.convertToJSON(configMap);
			
			assertTrue(result.length()>0);
		
		} catch (IOException e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testConvertToXML(){
		Loader loader = new Loader();
		
		Converter converter = new Converter();
		
		try {
			Map<String, Object> configMap = loader.load("example_1.txt");
			
			String result = converter.convertToXML(configMap);
			
			assertTrue(result.length()>0);
		
		} catch (IOException e) {
			fail(e.getMessage());
		}
	}
}
