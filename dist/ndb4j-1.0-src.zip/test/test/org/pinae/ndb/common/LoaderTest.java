package test.org.pinae.ndb.common;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.Map;

import org.junit.Test;
import org.pinae.ndb.common.Loader;

public class LoaderTest {
	@Test
	public void testLoad(){
		Loader loader = new Loader();
		
		Map<String, Object> ndb = null;
		
		try {
			ndb = loader.load("example_1.txt");
			assertEquals(ndb.size(), 1);
		} catch (IOException e) {
			fail(e.getMessage());
		}
		
		try {
			ndb = loader.load("example_2.txt");
			assertEquals(ndb.size(), 1);
		} catch (IOException e) {
			fail(e.getMessage());
		}
	}
	
}
